import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2_client = boto3.client('ec2')

def isolate_ec2_instance(instance_id):
    """
    Isola un'istanza EC2 compromessa modificando il gruppo di sicurezza dell'istanza.
    """
    try:
        # Quarantena
        security_group_id = 'sg-0ee645f2ff11d765b'  
        
        # Modifica l'attributo dell'istanza per associare il nuovo security group
        ec2_client.modify_instance_attribute(InstanceId=instance_id, Groups=[security_group_id])
        
        logger.info(f"Istanza {instance_id} isolata con successo.")
    except Exception as e:
        logger.error(f"Errore durante l'isolamento dell'istanza {instance_id}: {str(e)}")
        raise

def lambda_handler(event, context):
    """
    Handler principale della funzione Lambda.
    Esegue la risposta automatica agli incidenti di GuardDuty con gravità >= 7.
    """
    try:
        logger.info(f"Evento ricevuto: {json.dumps(event)}")

        detail = event.get('detail', {})
        severity = detail.get('severity', 0)

        if severity >= 7:
            logger.info(f"Gravità dell'incidente: {severity}. Eseguendo la risposta...")

            resource = detail.get('resource', {}).get('instanceDetails', {})
            instance_id = resource.get('instanceId')

            if instance_id:
                logger.info(f"Isolamento dell'istanza EC2 compromessa: {instance_id}")
                isolate_ec2_instance(instance_id)
            else:
                logger.warning("Nessuna istanza EC2 associata al finding di GuardDuty.")
        else:
            logger.info(f"Gravità dell'incidente troppo bassa: {severity}. Nessuna azione intrapresa.")

    except Exception as e:
        logger.error(f"Errore nel processare l'evento di GuardDuty: {str(e)}")
        raise

